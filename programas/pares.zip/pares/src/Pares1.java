public class Pares1 {
    public static void main(String[] args) {
        int x=2;
        for( x=2; x<=100; x++){
            if(x%2 ==0){
            System.out.println("numero par:"+x);
                    }
        }        
    }
}



